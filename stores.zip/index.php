<?php
// Simple redirect to dashboard
header("Location: dashboard.php");
exit;
?>