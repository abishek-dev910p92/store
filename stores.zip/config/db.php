<?php 
$conn = mysqli_connect ("localhost", "u473959262_minitgo", "Minitzgo#2025", "u473959262_minitgo") or die ("Database Not Connected!");
?>